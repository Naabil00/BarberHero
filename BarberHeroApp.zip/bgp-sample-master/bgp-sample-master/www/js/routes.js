angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.barbershopLocator', {
    url: '/page2',
    views: {
      'tab1': {
        templateUrl: 'templates/barbershopLocator.html',
        controller: 'barbershopLocatorCtrl'
      }
    }
  })

  .state('tabsController.yourAppointments', {
    url: '/page3',
    views: {
      'tab2': {
        templateUrl: 'templates/yourAppointments.html',
        controller: 'yourAppointmentsCtrl'
      }
    }
  })

  .state('tabsController.promotion', {
    url: '/page4',
    views: {
      'tab3': {
        templateUrl: 'templates/promotion.html',
        controller: 'promotionCtrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('myProfile', {
    url: '/page5',
    templateUrl: 'templates/myProfile.html',
    controller: 'myProfileCtrl'
  })

  .state('login', {
    url: '/page8',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signup', {
    url: '/page9',
    templateUrl: 'templates/signup.html',
    controller: 'signupCtrl'
  })

$urlRouterProvider.otherwise('/page1/page4')


});