
The config.xml is copied directly from PhoneGap Hello World config.xml file
(https://github.com/phonegap/phonegap-template-hello-world).
It consists of many plugins.
The default ionic startup codes require the following plugins only:
cordova-plugin-device,
cordova-plugin-console,
cordova-plugin-inappbrowser,
cordova-plugin-whitelist,
cordova-plugin-splashscreen,
cordova-plugin-statusbar,
ionic-plugin-keyboard.
You may delete other plugins that are not needed in config.xml
